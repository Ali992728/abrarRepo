package frames;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import entities.*;
import repositories.*;


public class EmployeeHomeFrame extends JFrame implements ActionListener
{
	
	private JButton customerBtn, orderBtn, orderLineBtn, designationBtn, salaryBtn, passBtn,backBtn;
	private JPanel panel;
	private JLabel imageLabel;
	public EmployeeHomeFrame()
	{
		super("Employee Home Frame");
		this.setSize(630,540);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		
		
		this.customerBtn=new JButton("Customer operation");
		this.customerBtn.setBounds(115,90,150,40);
		customerBtn.setBackground(Color.RED);
		this.customerBtn.addActionListener(this);
		this.panel.add(customerBtn);
		
		
		this.orderBtn=new JButton("Order");
		this.orderBtn.setBounds(115,160,150,40);
		orderBtn.setBackground(Color.RED);
		this.orderBtn.addActionListener(this);
		this.panel.add(orderBtn);
		
		
		this.orderLineBtn=new JButton("Order-Line");
		this.orderLineBtn.setBounds(115,220,150,40);
		orderLineBtn.setBackground(Color.RED);
		this.orderLineBtn.addActionListener(this);
		this.panel.add(orderLineBtn);
		
	
		
		this.designationBtn=new JButton("Designation");
		this.designationBtn.setBounds(315,90,150,40);
		designationBtn.setBackground(Color.RED);
		this.designationBtn.addActionListener(this);
		this.panel.add(designationBtn);
		
		
		this.salaryBtn=new JButton("Salary");
		this.salaryBtn.setBounds(315,160,150,40);
		salaryBtn.setBackground(Color.RED);
		this.salaryBtn.addActionListener(this);
		this.panel.add(salaryBtn);
		
		this.passBtn=new JButton("Update Password");
		this.passBtn.setBounds(315,220,150,40);
		passBtn.setBackground(Color.RED);
		this.passBtn.addActionListener(this);
		this.panel.add(passBtn);
		
		ImageIcon icon = new ImageIcon("emp.jpg"); 
		imageLabel = new JLabel(icon);
        imageLabel.setBounds(0, 0,626,538);
        panel.add(imageLabel);
		
		
		
		this.add(panel);
		
	}
	
	public void actionPerformed(ActionEvent ae)
	{

	}
	
}
